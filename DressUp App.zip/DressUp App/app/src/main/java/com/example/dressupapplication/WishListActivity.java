package com.example.dressupapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageButton;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class WishListActivity extends AppCompatActivity {

    WishListAdapter wishListAdapter;
    RecyclerView wishListRecycler;
    private DatabaseReference rootDatabaseref;
    private DatabaseReference rootSecondDatabaseref;

    ImageButton back_btn ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wish_list);

        back_btn = findViewById(R.id.wishList_BTN_back);

        back_btn.setOnClickListener(view -> {
            Intent intent = new Intent(WishListActivity.this,MainActivity.class);
            startActivity(intent);
            finish();
        });

        rootDatabaseref = FirebaseDatabase.getInstance().getReference().child("User");
        rootSecondDatabaseref = rootDatabaseref.child("wishList");
        rootSecondDatabaseref.addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        //Get map of users in datasnapshot
                        if (dataSnapshot.getValue()!=null) {
                            collectUsersProducts((Map<String, Object>) dataSnapshot.getValue());
                        }
                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        //handle databaseError
                    }
                });

    }

    private void collectUsersProducts(Map<String, Object> values) {

        ArrayList<WishList> wishListList = new ArrayList<>();
        for (Map.Entry<String, Object> entry : values.entrySet()){
            //Get  map
            Map singleProduct = (Map) entry.getValue();
            String price = String.valueOf(singleProduct.get("price"));
            String name = String.valueOf(singleProduct.get("ProductName"));

            wishListList.add(new WishList(name,price));
            setWishListRecycler(wishListList);
        }

    }

    private void setWishListRecycler(List<WishList> wishListList) {
        wishListRecycler = findViewById(R.id.wishList_RecycleView);
        RecyclerView.LayoutManager lm2 = new LinearLayoutManager(this, RecyclerView.VERTICAL,false);
        wishListRecycler.setLayoutManager(lm2);
        wishListAdapter = new WishListAdapter(this,wishListList);
        wishListRecycler.setAdapter(wishListAdapter);

    }
}