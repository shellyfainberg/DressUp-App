package com.example.dressupapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WishListAdapter extends RecyclerView.Adapter<WishListAdapter.WishListViewHolder>  {
    Context context;
    List<WishList> wishListList;

    public WishListAdapter(Context context, List<WishList> wishListList) {
        this.context = context;
        this.wishListList = wishListList;
    }

    @NonNull
    @Override
    public WishListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.activity_wish_list_item,parent,false);
        return new WishListViewHolder(view);
    }

    public static final class  WishListViewHolder extends RecyclerView.ViewHolder{
        TextView productName;
        TextView price;

        public WishListViewHolder(@NonNull View itemView) {
            super(itemView);
            price = itemView.findViewById(R.id.wishList_TXT_price);
            productName = itemView.findViewById(R.id.wishList_TXT_name);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull WishListViewHolder holder, int position) {
        holder.productName.setText(wishListList.get(position).getProductName());
        holder.price.setText(wishListList.get(position).getPrice());
    }

    @Override
    public int getItemCount() {
        return wishListList.size();
    }
}