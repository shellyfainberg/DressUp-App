package com.example.dressupapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

public class AddProductActivity extends AppCompatActivity {

   private Spinner addProduct_SNP_selectCategory;
   private Spinner addProduct_SNP_pickColor;
   private Spinner addProduct_SNP_shippingOption;
   private Spinner addProduct_SNP_condition;
   private EditText addProduct_ETXT_title;
   private EditText addProduct_ETXT_setPrice;
   private EditText addProduct_ETXT_description;

   private ImageButton imageNumber1;

   private ImageButton back_btn;
   private Button addProduct_BTN_save;
   private Button uploadImage;
   private String myLocation ="AddProduct";
   private String AddProductId;

    FirebaseStorage storage;
    StorageReference storageReference;
    ProgressDialog progressDialog;
    Bitmap bitmap;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);

        addProduct_SNP_selectCategory = (Spinner) findViewById(R.id.addProduct_SNP_selectCategory);
        addProduct_SNP_pickColor = (Spinner) findViewById(R.id.addProduct_SNP_pickColor);
        addProduct_SNP_shippingOption = (Spinner) findViewById(R.id.addProduct_SNP_shippingOption);
        addProduct_SNP_condition = (Spinner) findViewById(R.id.addProduct_SNP_condition);
        addProduct_BTN_save = findViewById(R.id.addProduct_BTN_save);
        back_btn = findViewById(R.id.addProduct_BTN_back);
        addProduct_ETXT_title =(EditText)findViewById(R.id.addProduct_ETXT_title);
        addProduct_ETXT_setPrice =(EditText) findViewById(R.id.addProduct_ETXT_setPrice);
        addProduct_ETXT_description = (EditText)findViewById(R.id.addProduct_ETXT_description);
        imageNumber1 = findViewById(R.id.imageNumber1);
        uploadImage=findViewById(R.id.uploadImage);
        AddProductId= UUID.randomUUID().toString();


        Intent cameraIntent = getIntent();
        String imageId = cameraIntent.getStringExtra("imageId");


        uploadImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                progressDialog = new ProgressDialog(AddProductActivity.this);
                progressDialog.setMessage("fetching image ...");
                progressDialog.setCancelable(false);
                progressDialog.show();

                String imageID=imageId;

                Log.d("aa-add","imageID"+imageID);

                storageReference = FirebaseStorage.getInstance().getReference("images/" + imageID);
                try {
                    File localFile = File.createTempFile("tempfile",".png");
                    storageReference.getFile(localFile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                            if (progressDialog.isShowing()){
                                progressDialog.dismiss();
                                bitmap = BitmapFactory.decodeFile(localFile.getAbsolutePath());
                                imageNumber1.setImageBitmap(bitmap);


                            }
                        }

                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            if (progressDialog.isShowing()){
                                progressDialog.dismiss();
                                Toast.makeText(AddProductActivity.this,"File to review",Toast.LENGTH_LONG).show();
                            }

                        }
                    });
                } catch (IOException e) {
                    e.printStackTrace();
                }


            }
        });


        back_btn.setOnClickListener(view -> {
            Intent intent = new Intent(AddProductActivity.this,MainActivity.class);
            intent.putExtra("AddProductId",AddProductId);
            startActivity(intent);
            finish();
        });

        imageNumber1.setOnClickListener(view ->  {
                Intent intent = new Intent(AddProductActivity.this,cameraActivity.class);
                intent.putExtra("myLocation",myLocation);
                startActivity(intent);
                finish();
        });


        ArrayAdapter<String> categoryAdapter;
        List<String> categoryList;

        categoryList = new ArrayList<String>();
        categoryList.add("Shirt");
        categoryList.add("Coat");
        categoryList.add("Dress");
        categoryList.add("Shorts");
        categoryList.add("Jeans");
        categoryAdapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_spinner_item, categoryList);
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        addProduct_SNP_selectCategory.setAdapter(categoryAdapter);



        ArrayAdapter<String> colorAdapter;
        List<String> colorList;

        colorList = new ArrayList<String>();
        colorList.add("Red");
        colorList.add("Blue");
        colorList.add("Green");
        colorList.add("Yellow");
        colorList.add("Pink");
        colorList.add("Black");
        colorList.add("White");
        colorAdapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_spinner_item, colorList);
        colorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        addProduct_SNP_pickColor.setAdapter(colorAdapter);



        ArrayAdapter<String> shippingAdapter;
        List<String> shippingList;

        shippingList = new ArrayList<String>();
        shippingList.add("Post office");
        shippingList.add("Home");
        shippingList.add("Store");
        shippingAdapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_spinner_item, shippingList);
        shippingAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        addProduct_SNP_shippingOption.setAdapter(shippingAdapter);


        ArrayAdapter<String> conditionAdapter;
        List<String> conditionList;

        conditionList = new ArrayList<String>();
        conditionList.add("New");
        conditionList.add("Used");
        conditionAdapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_spinner_item, conditionList);
        conditionAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        addProduct_SNP_condition.setAdapter(conditionAdapter);


        addProduct_BTN_save.setOnClickListener(view -> {

            String productName = addProduct_ETXT_title.getText().toString();
            String category = addProduct_SNP_selectCategory.getSelectedItem().toString();
            String color = addProduct_SNP_pickColor.getSelectedItem().toString();
            String shippingOption = addProduct_SNP_shippingOption.getSelectedItem().toString();
            String condition = addProduct_SNP_condition.getSelectedItem().toString();
            String price = addProduct_ETXT_setPrice.getText().toString();
            String description = addProduct_ETXT_description.getText().toString();

            HashMap<String,Object> map = new HashMap<>();
            map.put("productName",productName);
            map.put("category",category);
            map.put("color",color);
            map.put("shippingOption",shippingOption);
            map.put("condition",condition);
            map.put("price",price);
            map.put("description",description);
            Log.d("pp-price",price);
            Log.d("pp-description",map.toString());
            if (map.isEmpty()){
                Toast.makeText(AddProductActivity.this,"No category selected!",Toast.LENGTH_LONG).show();
            }
            else{
             Toast.makeText(AddProductActivity.this,"Data saved",Toast.LENGTH_LONG).show();
                FirebaseDatabase.getInstance().getReference().child("User").child("Products").child(AddProductId).setValue(map);
            }

            Intent intent = new Intent(AddProductActivity.this,AddProductActivity.class);
            startActivity(intent);
            finish();
        });

    }
}