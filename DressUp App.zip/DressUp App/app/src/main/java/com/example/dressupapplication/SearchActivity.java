package com.example.dressupapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class SearchActivity extends AppCompatActivity {

    ImageButton search_btn;
    ImageButton back_btn;
    ProductAdapter productAdapter;
    RecyclerView productRecycler;
    private EditText searchFilter;
    private ImageButton cameraSearch;
    private String myLocation ="SearchProduct";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        search_btn = findViewById(R.id.search_BTN_back);
        back_btn = findViewById(R.id.search_BTN_back);
        searchFilter= findViewById(R.id.search_EDT_filter);
        cameraSearch= findViewById(R.id.search_BTN_camera);

        searchFilter.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                (SearchActivity.this).productAdapter.getFilter().filter(s);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        search_btn.setOnClickListener(view -> {
            Intent intent = new Intent(SearchActivity.this,MainActivity.class);
            startActivity(intent);
            finish();
        });

        back_btn.setOnClickListener(view -> {
            Intent intent = new Intent(SearchActivity.this,MainActivity.class);
            startActivity(intent);
            finish();
        });

        cameraSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SearchActivity.this,cameraActivity.class);
                intent.putExtra("myLocation",myLocation);
                startActivity(intent);
                finish();

            }
        });
        Intent myIntent = getIntent();
        String categoryId = myIntent.getStringExtra("categoryId");
        String imageColorNumber = myIntent.getStringExtra("imageColorNumber");

        if (categoryId.equals("")){
            categoryId="27108";
        }
        if (imageColorNumber.equals("")){
            imageColorNumber="17";
        }

        OkHttpClient client = new OkHttpClient();
        String url = "https://asos2.p.rapidapi.com/products/v2/list?store=US&offset=0&categoryId="+categoryId+"&limit=20&country=US&sort=freshness&currency=USD&sizeSchema=US&base_colour="+imageColorNumber+"&lang=en-US";
        Request request = new Request.Builder()
                .url(url)
                .get()
                .addHeader("X-RapidAPI-Host", "asos2.p.rapidapi.com")
                .addHeader("X-RapidAPI-Key", "5dafd74be2msh078bbfa50b4eb8ap17d25ajsnb1deda5f0f45")
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    final String myResponse = response.body().string();
                    SearchActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                JSONObject reader = new JSONObject(myResponse);
                                JSONArray products = reader.getJSONArray("products");
                                List<Product> productList = new ArrayList<>();
                                ArrayList<String> names = new ArrayList<>(); //filter
                                for(int i = 0;i < products.length();i++)
                                {
                                    JSONObject product = products.getJSONObject(i);
                                    String name = product.getString("name");
                                    String fullprice= product.getString("price");
                                    String price =fullprice.substring(32,35);
                                    if (!price.contains("$")){
                                        price="$"+price;
                                    }
                                    String url = product.getString("imageUrl");
                                    productList.add(new Product(i,name,url,price));
                                    names.add(name);

                                }

                                setProductRecycler(productList);


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    });
                }
            }
        });

    }

    private void  setProductRecycler(List<Product> productList){
        productRecycler = findViewById(R.id.recyclerView_search);
        RecyclerView.LayoutManager LayoutManager = new LinearLayoutManager(this , RecyclerView.VERTICAL,false);
        productRecycler.setLayoutManager(LayoutManager);
        productAdapter=new ProductAdapter(this,productList,productList);
        productRecycler.setAdapter(productAdapter);
    }
}