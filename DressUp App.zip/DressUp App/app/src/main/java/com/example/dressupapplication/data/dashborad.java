package com.example.dressupapplication.data;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.dressupapplication.R;
import com.google.firebase.auth.FirebaseAuth;

public class dashborad extends AppCompatActivity {
    Button dashborad_BTN_logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashbarod);
        dashborad_BTN_logout = findViewById(R.id.dashborad_BTN_logout);
        dashborad_BTN_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                finish();
            }
        });

    }
}