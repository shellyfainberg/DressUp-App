package com.example.dressupapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MyClosetAdapter extends RecyclerView.Adapter<MyClosetAdapter.MyClosetViewHolder>{
    Context context;
    List<MyCloset> myClosetList;

    public MyClosetAdapter(Context context, List<MyCloset> myClosetList) {
        this.context = context;
        this.myClosetList = myClosetList;
    }

    @NonNull
    @Override
    public MyClosetViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.activity_user_page_list,parent,false);

        return new MyClosetViewHolder(view);
    }

    public static final class MyClosetViewHolder extends RecyclerView.ViewHolder{
        TextView ProductTitle;
        TextView ProductCategory;
        TextView ProductPrice;
        TextView ProductColor;
        TextView ProductCondition;
        TextView ProductDescription;
        TextView ShippingOption;

        public MyClosetViewHolder(@NonNull View itemView) {
            super(itemView);
            ProductTitle = itemView.findViewById(R.id.mainList_TXT_title);
            ProductCategory = itemView.findViewById(R.id.mainList_TXT_category);
            ProductPrice= itemView.findViewById(R.id.mainList_TXT_price);
            ProductColor = itemView.findViewById(R.id.mainList_TXT_color);
            ProductCondition= itemView.findViewById(R.id.mainList_TXT_condition);
            ProductDescription= itemView.findViewById(R.id.mainList_TXT_description);
            ShippingOption= itemView.findViewById(R.id.mainList_TXT_shippingOption);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull MyClosetViewHolder holder, int position) {
        holder.ProductTitle.setText(myClosetList.get(position).getTitle());
        holder.ProductCategory.setText(myClosetList.get(position).getCategory());
        holder.ProductColor.setText(myClosetList.get(position).getColor());
        holder.ShippingOption.setText(myClosetList.get(position).getShippingOption());
        holder.ProductCondition.setText(myClosetList.get(position).getCondition());
        holder.ProductPrice.setText(myClosetList.get(position).getPrice());
    }

    @Override
    public int getItemCount() {
        return myClosetList.size();
    }
}

