package com.example.dressupapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageButton;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ShoppingCartActivity extends AppCompatActivity {

    ImageButton back_btn;
    Button continue_btn;

    ShoppingCartAdapter shoppingCartAdapter;
    RecyclerView shoppingCartRecycler;
    private DatabaseReference rootDatabaseref;
    private DatabaseReference rootSecondDatabaseref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_cart);

        back_btn = findViewById(R.id.shoppingCart_BTN_back);
        continue_btn = findViewById(R.id.shoppingCart_BTN_continue);

        back_btn.setOnClickListener(view -> {
            Intent intent = new Intent(ShoppingCartActivity.this,MainActivity.class);
            startActivity(intent);
            finish();
        });

        continue_btn.setOnClickListener(view -> {
            Intent intent = new Intent(ShoppingCartActivity.this,PaymentActivity.class);
            startActivity(intent);
            finish();
        });

        rootDatabaseref = FirebaseDatabase.getInstance().getReference().child("User");
        rootSecondDatabaseref = rootDatabaseref.child("shoppingCart");
        rootSecondDatabaseref.addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        //Get map of users in datasnapshot
                        if (dataSnapshot.getValue()!=null) {
                            collectUsersProducts((Map<String, Object>) dataSnapshot.getValue());
                        }
                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        //handle databaseError
                        Log.d("pp-userpage","databaseError"+databaseError);
                    }
                });

    }

    private void collectUsersProducts(Map<String, Object> values) {

        ArrayList<ShoppingCart> shoppingCart = new ArrayList<>();
        for (Map.Entry<String, Object> entry : values.entrySet()){
            //Get  map
            Map singleProduct = (Map) entry.getValue();
            String price = String.valueOf(singleProduct.get("price"));
            String name = String.valueOf(singleProduct.get("ProductName"));

            shoppingCart.add(new ShoppingCart(name,price));
            setShoppingCartRecycler(shoppingCart);
        }

    }

    private void setShoppingCartRecycler(List<ShoppingCart> shoppingCartList) {
        shoppingCartRecycler = findViewById(R.id.shoppingCart_recyclerView);
        RecyclerView.LayoutManager LayoutManager = new LinearLayoutManager(this , RecyclerView.VERTICAL,false);
        shoppingCartRecycler.setLayoutManager(LayoutManager);
        shoppingCartAdapter=new ShoppingCartAdapter(this,shoppingCartList);
        shoppingCartRecycler.setAdapter(shoppingCartAdapter);
    }


}