package com.example.dressupapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;

public class SettingActivity extends AppCompatActivity {

    ImageButton back_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        back_btn = findViewById(R.id.setting_BTN_back);

        back_btn.setOnClickListener(view -> {
            Intent intent = new Intent(SettingActivity.this,MainActivity.class);
            startActivity(intent);
            finish();
        });
    }
}