package com.example.dressupapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.dressupapplication.data.dashborad;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class manageotp extends AppCompatActivity {

    EditText managetop_EDT_optCode;
    Button managetop_BTN_verify;
    String phoneNumber;
    String otpid;
    private FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manageotp);

        phoneNumber=getIntent().getStringExtra("mobile").toString();
        managetop_EDT_optCode = findViewById(R.id.managetop_EDT_optCode);
        managetop_BTN_verify = findViewById(R.id.managetop_BTN_verify);
        mAuth = FirebaseAuth.getInstance();

        initiateopt();
        managetop_BTN_verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (managetop_EDT_optCode.toString().isEmpty()){
                    Toast.makeText(getApplicationContext(),"Blank Field can not be processed ",Toast.LENGTH_LONG).show();
                }

                else if (managetop_EDT_optCode.toString().length()<6){
                    Toast.makeText(getApplicationContext(),"Invalis OTP ",Toast.LENGTH_LONG).show();

                }


                else{
                    PhoneAuthCredential credential = PhoneAuthProvider.getCredential(otpid,managetop_EDT_optCode.getText().toString());
                    signInWithPhoneAuthCredential(credential);
                }
            }
        });
        

    }

    private void initiateopt() {
        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber(phoneNumber)       // Phone number to verify
                        .setTimeout(60L, TimeUnit.SECONDS) // Timeout and unit
                        .setActivity(this)                 // Activity (for callback binding)
                        .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

                            @Override
                            public void onCodeSent(String s,PhoneAuthProvider.ForceResendingToken forceResendingToken){
                                otpid=s;

                            }

                            @Override
                            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                                signInWithPhoneAuthCredential(phoneAuthCredential);
                            }

                            @Override
                            public void onVerificationFailed(@NonNull FirebaseException e) {
                                Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();


                            }
                        })          // OnVerificationStateChangedCallbacks
                        .build();
        PhoneAuthProvider.verifyPhoneNumber(options);


    }
        private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
            mAuth.signInWithCredential(credential)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                startActivity(new Intent(manageotp.this, MainActivity.class));
                                finish();

                            } else {
                                Toast.makeText(getApplicationContext(),"Signin code error",Toast.LENGTH_LONG).show();

                            }
                        }
                    });
        }
}