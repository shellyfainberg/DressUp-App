package com.example.dressupapplication;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.palette.graphics.Palette;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.service.controls.templates.ThumbnailTemplate;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.dressupapplication.ml.FashionModel;
import com.google.android.gms.common.util.IOUtils;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.tensorflow.lite.DataType;
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer;
import org.w3c.dom.Text;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import java.util.UUID;

public class cameraActivity extends AppCompatActivity {
    private ImageView openImage;
    private Button openCameraButton;
    private Button openCameraGallery;
    private ImageButton backBtn;
    private TextView Colorresult;
    private Button openSearch;
    private static final int PICK_IMAGE = 1;
    private static final int CAMERA_IMAGE = 2;
    int imageSize = 28;
    private boolean getImage;
    private String imageColorNumber;
    private Palette.Swatch vibrantSwatch;
    private String imageId;
    FirebaseStorage storage;
    StorageReference storageReference;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);

        backBtn = findViewById(R.id.camera_TXT_back);
        openImage = findViewById(R.id.IMG_openCamera);
        Colorresult = findViewById(R.id.TXT_result);
        openSearch = findViewById(R.id.BTM_openSearch);
        openCameraButton = findViewById(R.id.BTM_openCamera);
        openCameraGallery = findViewById(R.id.BTM_openCameraGallery);
        getImage = false;
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();
        imageId = UUID.randomUUID().toString();


        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 101);

        }

        openCameraButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, CAMERA_IMAGE);
            }
        });

        openCameraGallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent gallery = new Intent();
                gallery.setType("image/*");
                gallery.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(gallery, "select image"), PICK_IMAGE);
            }
        });

        Intent cameraIntent = getIntent();
        String myLocation = cameraIntent.getStringExtra("myLocation");

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (myLocation.equals("AddProduct")) {
                    Intent intent = new Intent(cameraActivity.this, AddProductActivity.class);
                    intent.putExtra("imageId", imageId);
                    startActivity(intent);
                    finish();


                } else if (myLocation.equals("SearchProduct")) {
                    Intent intent = new Intent(cameraActivity.this, SearchActivity.class);
                    intent.putExtra("categoryId", "");
                    intent.putExtra("imageColorNumber", "");
                    startActivity(intent);
                    finish();
                } else if (myLocation.equals("mainPage")) {
                    Intent intent = new Intent(cameraActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();

                }
            }
        });


        openSearch.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                File myimage = new File("/Users/shellyfainberg/Downloads/Dress/app/src/main/res/drawable/shirt.png");
                if (myimage.exists()) {
                }
                Bitmap bmp = ((BitmapDrawable) openImage.getDrawable()).getBitmap();


                File folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/EmailClient/");
                folder.mkdirs();
                File file = new File(folder, "sketchpad.png");
                try {
                    file.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                FileOutputStream fOut = null;
                try {
                    fOut = new FileOutputStream(file);

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

                bmp.compress(Bitmap.CompressFormat.PNG, 85, fOut);


                try {
                    fOut.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {

                    fOut.close();

                } catch (IOException e) {
                    e.printStackTrace();
                }


                OkHttpClient client = new OkHttpClient();
                RequestBody body = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart("image", "sketchpad.png",
                                RequestBody.create(MediaType.parse("text/plain"), file))
//            .addFormDataPart("url", "https://storage.googleapis.com/api4ai-static/samples/fashion-1.jpg")
                        .build();

                Request request = new Request.Builder()
                        .url("https://fashion4.p.rapidapi.com/v1/results")
                        .post(body)
                        .addHeader("content-type", "application/x-www-form-urlencoded")
                        .addHeader("X-RapidAPI-Host", "fashion4.p.rapidapi.com")
                        .addHeader("X-RapidAPI-Key", "5dafd74be2msh078bbfa50b4eb8ap17d25ajsnb1deda5f0f45")
                        .build();


                client.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(@NonNull Call call, @NonNull IOException e) {
                    }

                    @Override
                    public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                        if (response.isSuccessful()) {
                            final String myResponse = response.body().string();
                            cameraActivity.this.runOnUiThread(new Runnable() {

                                @Override
                                public void run() {

                                    try {
                                        JSONObject reader = new JSONObject(myResponse);
                                        JSONArray results = reader.getJSONArray("results");
                                        JSONObject result = results.getJSONObject(0);
                                        String classes = result.getString("entities");
                                        String classesNames = classes.substring(54, classes.length() - 2);
                                        String finalNames = classesNames.replace("top, t-shirt, sweatshirt", "top-t-shirt-sweatshirt");


                                        HashMap<String, String> map = new HashMap<String, String>();
                                        JSONObject jObject = new JSONObject(finalNames);
                                        Iterator<?> keys = jObject.keys();
                                        double maxvalue = 0.0;
                                        String res = "";

                                        while (keys.hasNext()) {
                                            String key = (String) keys.next();
                                            String value = jObject.getString(key);
                                            map.put(key, value);

                                        }

                                        Iterator myVeryOwnIterator = map.keySet().iterator();
                                        while (myVeryOwnIterator.hasNext()) {
                                            String key = (String) myVeryOwnIterator.next();
                                            double value = Double.valueOf((String) map.get(key));
                                            if (value > maxvalue) {
                                                maxvalue = value;
                                                res = key;
                                            }

                                        }


                                        String categoryId = "";
                                        switch (res) {
                                            case "top-t-shirt-sweatshirt":
                                                categoryId = "4169";
                                                break;
                                            case "trousers":
                                                categoryId = "3630";
                                                break;
                                            case "footwear":
                                                categoryId = "4172";
                                                break;
                                            case "skirt":
                                                categoryId = "2639";
                                                break;
                                            case "dress":
                                                categoryId = "8799";
                                                break;
                                            case "shorts":
                                                categoryId = "9263";
                                                break;
                                            case "sock":
                                                categoryId = "7657";
                                                break;

                                        }


                                        Intent myintent = new Intent(cameraActivity.this, SearchActivity.class);
                                        myintent.putExtra("categoryId", categoryId);
                                        myintent.putExtra("imageColorNumber", imageColorNumber);
                                        startActivity(myintent);
                                        finish();

                                    } catch (JSONException e) {
                                        Log.d("ppp-0", "JSONException" + e);
                                        e.printStackTrace();
                                    }

                                }
                            });


                        }
                    }


                });

            }
        });

    }

    public void classifyImage(Bitmap image) {
        try {
            FashionModel model = FashionModel.newInstance(getApplicationContext());

            // Creates inputs for reference.
            TensorBuffer inputFeature0 = TensorBuffer.createFixedSize(new int[]{1, 28, 28}, DataType.FLOAT32);
            ByteBuffer byteBuffer = ByteBuffer.allocateDirect(4 * 28 * 28);
            inputFeature0.loadBuffer(byteBuffer);

            byteBuffer.order(ByteOrder.nativeOrder());
            int[] intValues = new int[imageSize * imageSize];
            image.getPixels(intValues, 0, image.getWidth(), 0, 0, image.getWidth(), image.getHeight());
            int pixel = 0;
            for (int i = 0; i < imageSize; i++) {
                for (int j = 0; j < imageSize; j++) {
                    int val = intValues[pixel++];
//                    byteBuffer.putFloat(((val>>16)&0xFF)*(1.f/255));//255
//                    byteBuffer.putFloat(((val>>6)&0xFF)*(1.f/255)); //255
//                    byteBuffer.putFloat(((val>>0xFF)&0xFF)*(1.f/255)); //255

                }
            }
            inputFeature0.loadBuffer(byteBuffer);

            // Runs model inference and gets result.
            FashionModel.Outputs outputs = model.process(inputFeature0);
            TensorBuffer outputFeature0 = outputs.getOutputFeature0AsTensorBuffer();


            float[] confidences = outputFeature0.getFloatArray();
            Log.d("confidences", confidences.toString());
            int maxPos = 0;
            float maxConfidences = 0;
            for (int i = 0; i < confidences.length; i++) {
//                Log.d("",confidences.length().toString());
                if (confidences[i] > maxConfidences) {
                    maxConfidences = confidences[i];
                    maxPos = i;
                }
            }

            String[] classes = {"T-shirt/top", "Trouser", "Pullover", "Dress", "Coat",
                    "Sandal", "Shirt", "Sneaker", "Bag", "Ankle boot"};

            Colorresult.setText(classes[maxPos]);


            // Releases model resources if no longer used.
            model.close();
        } catch (IOException e) {
            // TODO Handle the exception
        }

    }


//    public void imagesReco(Bitmap image) {
////        String filePath = Environment.getExternalStorageDirectory().toString() + "/drawable";

////        File imageFile = new File(filePath,fileName);
////       FileOutputStream fileOuputStream;
//        try {
//
//            FileOutputStream fos = new FileOutputStream(new File(getFilesDir(), "testing.jpg"));
////            fileOuputStream =  new FileOutputStream("testing.jpg");
////            os = new FileOutputStream();
//            image.compress(Bitmap.CompressFormat.JPEG, 100, fos);
//
////            os.flush();
////            os.close();
//        } catch (Exception e) {
//            Log.e(getClass().getSimpleName(), "Error writing bitmap", e);
//        }
//    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE) {
            Uri dat = data.getData();
            Bitmap image = null;

            try {
                image = MediaStore.Images.Media.getBitmap(this.getContentResolver(), dat);

            } catch (IOException e) {
                e.printStackTrace();
            }
            openImage.setImageBitmap(image);
            uploadImageToFB(dat);

            Palette.from(image).generate(new Palette.PaletteAsyncListener() {
                @Override
                public void onGenerated(@Nullable Palette palette) {
                    String hexColor = String.format("#%06X", (0xFFFFFF & palette.getDominantColor(1)));

                    getColorName(hexColor);

                }
            });

        } else if (requestCode == CAMERA_IMAGE) {
            Bitmap image = (Bitmap) data.getExtras().get("data");
            int dimension = Math.min(image.getWidth(), image.getHeight());
            image = ThumbnailUtils.extractThumbnail(image, dimension, dimension);
            openImage.setImageBitmap(image);

            Palette.from(image).generate(new Palette.PaletteAsyncListener() {
                @Override
                public void onGenerated(@Nullable Palette palette) {
                    String hexColor = String.format("#%06X", (0xFFFFFF & palette.getDominantColor(1)));
                    getColorName(hexColor);


                }
            });

        }


    }

    private void uploadImageToFB(Uri bat) {
        if (bat != null) {


            ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Uploading...");
            progressDialog.show();

            // Defining the child of storageReference
            StorageReference ref = storageReference.child("images/" + imageId);

            ref.putFile(bat)
                    .addOnSuccessListener(
                            new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                @Override
                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                    // Image uploaded successfully
                                    // Dismiss dialog
                                    progressDialog.dismiss();
                                    Toast.makeText(cameraActivity.this, "Image Uploaded!!", Toast.LENGTH_SHORT).show();
                                }
                            })

                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            // Error, Image not uploaded
                            progressDialog.dismiss();
                            Toast.makeText(cameraActivity.this, "Failed " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnProgressListener(
                            new OnProgressListener<UploadTask.TaskSnapshot>() {
                                // Progress Listener for loading
                                // percentage on the dialog box
                                @Override
                                public void onProgress(
                                        UploadTask.TaskSnapshot taskSnapshot) {
                                    double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                                    progressDialog.setMessage("Uploaded " + (int) progress + "%");
                                }
                            });
        }


    }


    public String getColorName(String hexColor) {
        String name = "";
        switch (hexColor.toLowerCase()) {

            case "#ff0000":
                name = "Red";
                break;
            case "#a00000":
                name = "Red";
                imageColorNumber = "1";
                break;
            case "#00ff00":
                name = "Green";
                break;
            case "#0000ff":
                name = "Blue";
                break;
            case "#ffffff":
                name = "White";
                break;
            case "#e8e8e8":
                name = "Grey/white";
                imageColorNumber = "5";
                break;
            case "#101010":
                name = "Black";
                imageColorNumber = "4";
                break;
            case "#e0e0e0":
                name = "jeans";
                imageColorNumber = "3";
                break;
            default:
                name = "Unknown";
                imageColorNumber = "";
                break;
        }
        return name;
    }

}