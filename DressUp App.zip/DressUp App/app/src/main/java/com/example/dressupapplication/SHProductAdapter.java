package com.example.dressupapplication;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

public class SHProductAdapter  extends RecyclerView.Adapter<SHProductAdapter.SHProductViewHolder> implements Filterable {
    Context context;
    List<SHProduct> SHProductList;
    private List<SHProduct> SHProductListFull;


    public SHProductAdapter(Context context, List<SHProduct> SHProductList,List<SHProduct> SHProductListFull) {
        this.context = context;
        this.SHProductList = SHProductList;
        this.SHProductListFull = new ArrayList<>(SHProductList);

    }

    public  static final class SHProductViewHolder extends  RecyclerView.ViewHolder{
        ImageView UrlImage;
        TextView ProductName;
        TextView ProductPrice;
        TextView ProductDescription;
        TextView ProductShippingOption;
        TextView ProductCondition;
        TextView ProductColor;
        TextView ProductCategory;
        CheckBox addToWishList;
        ImageButton addCartShopping;
        private String AddProductId;


        public SHProductViewHolder(@NonNull View itemView) {
            super(itemView);
            ProductName  = itemView.findViewById(R.id.mainList_TXT_title);
            ProductPrice = itemView.findViewById(R.id.mainList_TXT_price);
            ProductDescription = itemView.findViewById(R.id.mainList_TXT_description);
            ProductShippingOption = itemView.findViewById(R.id.mainList_TXT_shippingOption);
            ProductCondition = itemView.findViewById(R.id.mainList_TXT_condition);
            ProductColor = itemView.findViewById(R.id.mainList_TXT_color);
            ProductCategory = itemView.findViewById(R.id.mainList_TXT_category);
            UrlImage= (ImageView) itemView.findViewById(R.id.mainList_IMV_productView);
            addToWishList = itemView.findViewById(R.id.mainList_IMB_heart);
            addCartShopping=itemView.findViewById(R.id.mainList_IMB_shopping);
            AddProductId= UUID.randomUUID().toString();


            addToWishList.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    HashMap<String,Object> wishlist = new HashMap<>();
                    String name= ProductName.getText().toString();
                    String price = ProductPrice.getText().toString();

                    wishlist.put("ProductName",name);
                    wishlist.put("price",price);

                    FirebaseDatabase.getInstance().getReference().child("User").child("wishList").child(AddProductId).setValue(wishlist);


                }
            });

            addCartShopping.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    HashMap<String,Object> shoppingCart = new HashMap<>();

                    String name= ProductName.getText().toString();
                    String price = ProductPrice.getText().toString();

                    shoppingCart.put("ProductName",name);
                    shoppingCart.put("price",price);


                    FirebaseDatabase.getInstance().getReference().child("User").child("shoppingCart").child(AddProductId).setValue(shoppingCart);

                }
            });
        }
    }

    @NonNull
    @Override
    public SHProductAdapter.SHProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.activity_main_list,parent,false);
        return new SHProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SHProductAdapter.SHProductViewHolder holder, int position) {
        holder.ProductName.setText(SHProductList.get(position).getProductName());
        holder.ProductPrice.setText(SHProductList.get(position).getProductPrice());
        holder.ProductDescription.setText(SHProductList.get(position).getDescription());
        holder.ProductShippingOption.setText(SHProductList.get(position).getShippingMethod());
        holder.ProductCondition.setText(SHProductList.get(position).getCondition());
        holder.ProductColor.setText(SHProductList.get(position).getColor());
        holder.ProductCategory.setText(SHProductList.get(position).getCategory());
        SHProduct current = SHProductList.get(position);

    }

    @Override
    public int getItemCount() {
        return SHProductList.size();
    }

    @Override
    public Filter getFilter() {
        return shProductFilter;
    }

    private Filter shProductFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            List<SHProduct> filteredList = new ArrayList<>();

            if (constraint == null || constraint.length() == 0) {
                filteredList.addAll(SHProductListFull);
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();

                for (SHProduct item : SHProductListFull) {
                    if (item.getProductName().toLowerCase().contains(filterPattern)) {
                        filteredList.add(item);
                    }else if(item.getCategory().toLowerCase().contains(filterPattern)) {
                        filteredList.add(item);
                    }
                }
            }
            FilterResults results = new FilterResults();
            results.values = filteredList;
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            SHProductList.clear();
            SHProductList.addAll((List) results.values);
            notifyDataSetChanged();
        }
    };
}
