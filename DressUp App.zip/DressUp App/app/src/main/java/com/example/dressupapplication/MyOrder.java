package com.example.dressupapplication;

public class MyOrder {
    String productPrice;

    String productSize;

    public MyOrder(String productPrice, String productCount, String productSize) {
        this.productPrice = productPrice;

        this.productSize = productSize;
    }

    public String getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(String productPrice) {
        this.productPrice = productPrice;
    }

    public String getProductSize() {
        return productSize;
    }

    public void setProductSize(String productSize) {
        this.productSize = productSize;
    }
}
