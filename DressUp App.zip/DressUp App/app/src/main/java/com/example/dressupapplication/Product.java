package com.example.dressupapplication;

public class Product {

    Integer productId;
    String productName;
    String productPrice;
    String url;
    
    
    public Product(Integer productId, String productName,String url,String productPrice) { //use in product list - home page
        this.productId = productId;
        this.productName = productName;
        this.productPrice=productPrice;
        this.url =url;

    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductID(Integer productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(String productPrice) {
        this.productPrice = productPrice;
    }
}
