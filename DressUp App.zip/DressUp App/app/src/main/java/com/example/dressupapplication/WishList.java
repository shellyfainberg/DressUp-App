package com.example.dressupapplication;

import android.widget.ImageButton;

public class WishList {

    String price;
    String productName;


    public WishList(String productName, String price) {
        this.price = price;
        this.productName = productName;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }
}
