package com.example.dressupapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class PaymentActivity extends AppCompatActivity {

   private ImageButton back_btn;
   private Button applyPayment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        back_btn=findViewById(R.id.payment_TXT_back);
        applyPayment= findViewById(R.id.payment_TXT_apply);

        back_btn.setOnClickListener(view -> {
            Intent intent = new Intent(PaymentActivity.this,ShoppingCartActivity.class);
            startActivity(intent);
            finish();
        });

        applyPayment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(PaymentActivity.this, "Payment passed !!", Toast.LENGTH_SHORT).show();



            }
        });
    }
}