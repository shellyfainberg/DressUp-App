package com.example.dressupapplication;

public class SHProduct {

        String productName;
        String productPrice;
        String url;
        String condition;
        String description;
        String shippingMethod;
        String color;
        String category;

        public SHProduct( String url,String productName, String productPrice ,String condition, String description, String shippingMethod, String color, String category) {

            this.productName = productName;
            this.productPrice = productPrice;
            this.url = url;
            this.condition = condition;
            this.description = description;
            this.shippingMethod = shippingMethod;
            this.color = color;
            this.category = category;
        }


        public String getProductName() {
            return productName;
        }

        public void setProductName(String productName) {
            this.productName = productName;
        }

        public String getProductPrice() {
            return productPrice;
        }

        public void setProductPrice(String productPrice) {
            this.productPrice = productPrice;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public String getCondition() {
            return condition;
        }

        public void setCondition(String condition) {
            this.condition = condition;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getShippingMethod() {
            return shippingMethod;
        }

        public void setShippingMethod(String shippingMethod) {
            this.shippingMethod = shippingMethod;
        }
        public String getColor() {
            return color;
        }

        public void setColor(String color) {
            this.color = color;
        }

        public String getCategory() {
            return category;
        }

        public void setCategory(String category) {
            this.category = category;
        }
}
