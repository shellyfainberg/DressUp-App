package com.example.dressupapplication;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> implements Filterable {
    Context context;
    List<Product> productList;
    List<Product> productListFull;

    public ProductAdapter(Context context, List<Product> productList,List<Product> productListFull) {
        this.context = context;
        this.productList = productList;
        this.productListFull = new ArrayList<> (productList);
    }

    public static final class ProductViewHolder extends RecyclerView.ViewHolder{
        TextView ProductName;
        TextView ProductPrice;
        ImageView UrlImage;
        CheckBox addToWishList;
        ImageButton addToCart;
        private String AddProductId;

        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            ProductName = itemView.findViewById(R.id.productList_TXT_product_name);
            ProductPrice= itemView.findViewById(R.id.productList_TXT_product_price);
            UrlImage = (ImageView) itemView.findViewById(R.id.productList_IMV_image);
            addToWishList  = itemView.findViewById(R.id.productList_IMV_heart);
            addToCart = itemView.findViewById(R.id.productList_IMV_shoppinCart);
            AddProductId = UUID.randomUUID().toString();


            addToWishList.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    HashMap<String,Object> wishlist = new HashMap<>();
                    String name= ProductName.getText().toString();
                    String price = ProductPrice.getText().toString();
                    wishlist.put("ProductName",name);
                    wishlist.put("price",price);
               FirebaseDatabase.getInstance().getReference().child("User").child("wishList").child(AddProductId).setValue(wishlist);
                }
            });

            addToCart.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    HashMap<String,Object> shoppingCart = new HashMap<>();
                    String name= ProductName.getText().toString();
                    String price = ProductPrice.getText().toString();

                    shoppingCart.put("ProductName",name);
                    shoppingCart.put("price",price);

                    FirebaseDatabase.getInstance().getReference().child("User").child("shoppingCart").child(AddProductId).setValue(shoppingCart);

                }
            });
        }
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
           View view = LayoutInflater.from(context).inflate(R.layout.activity_product_list,parent,false);
        return new ProductViewHolder(view) ;
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        holder.ProductName.setText(productList.get(position).getProductName());
        holder.ProductPrice.setText(productList.get(position).getProductPrice());
        Product current = productList.get(position);
        String strUrl="https://"+current.getUrl();
        Picasso.get().load(strUrl).into(holder.UrlImage);
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    @Override
    public Filter getFilter() {
        return ProductFilter;
    }

    private Filter ProductFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            List<Product> filteredList = new ArrayList<>();

            if (constraint == null || constraint.length() == 0) {
                filteredList.addAll(productListFull);
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();

                for (Product item : productListFull) {
                    if (item.getProductName().toLowerCase().contains(filterPattern)) {
                        filteredList.add(item);
                    }
                }
            }
            FilterResults results = new FilterResults();
            results.values = filteredList;
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            productList.clear();
            productList.addAll((List) results.values);
            notifyDataSetChanged();
        }
    };
}









