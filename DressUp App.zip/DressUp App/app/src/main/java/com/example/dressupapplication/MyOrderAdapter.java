package com.example.dressupapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MyOrderAdapter extends RecyclerView.Adapter<MyOrderAdapter.MyOrderViewHolder> {
    Context context;
    List<MyOrder> myOrderList;

    public MyOrderAdapter(Context context, List<MyOrder> myOrderList) {
        this.context = context;
        this.myOrderList = myOrderList;
    }

    public static final class MyOrderViewHolder extends RecyclerView.ViewHolder{
        TextView Price;

        public MyOrderViewHolder(@NonNull View itemView) {
            super(itemView);
            Price = itemView.findViewById(R.id.mainList_TXT_price);
        }
    }

    @NonNull
    @Override
    public MyOrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.activity_user_page_list,parent,false);

        return new MyOrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyOrderViewHolder holder, int position) {
        holder.Price.setText(myOrderList.get(position).getProductPrice());
    }

    @Override
    public int getItemCount() {
        return myOrderList.size();
    }




}
