package com.example.dressupapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    //////last version ////
    private ImageButton user_page_btn;
    private ImageButton addProductPage_btn;
    private ImageButton shoppingCart_btn;
    private ImageButton wishList_btn;
    private ImageButton asosSearch_btn;
    private ImageButton search_BTN_camera;
    private EditText searchByText;


    private ImageButton addToShoppingCart;
    private CheckBox addToWishList;
    List<ShoppingCart> shoppingCartList = new ArrayList<>();
    List<WishList> wishListList = new ArrayList<>();

    //Adapter main
    SHProductAdapter shproductAdapter;
    RecyclerView shproductRecycler;

    ArrayList<SHProduct> productInfo = new ArrayList<>();

    private Button read_data;
    private DatabaseReference rootDatabaseref;
    private DatabaseReference rootSecondDatabaseref;
    private String myLocation ="mainPage";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        user_page_btn = findViewById(R.id.home_BTN_userPage);
        addProductPage_btn = findViewById(R.id.home_BTN_addProductPage);
        shoppingCart_btn = findViewById(R.id.home_BTN_cartPage);
        wishList_btn = findViewById(R.id.home_BTN_wishList);
        asosSearch_btn = findViewById(R.id.home_BTN_asosSearch);
        addToShoppingCart = findViewById(R.id.mainList_IMB_shopping);
        addToWishList = findViewById(R.id.mainList_IMB_heart);
        searchByText = findViewById(R.id.search_EDT_filter);
        search_BTN_camera=findViewById(R.id.search_BTN_camera);

        rootDatabaseref = FirebaseDatabase.getInstance().getReference().child("User");
        rootSecondDatabaseref = rootDatabaseref.child("Products");
        rootSecondDatabaseref.addListenerForSingleValueEvent(
            new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        //Get map of users in datasnapshot
                        if (dataSnapshot.getValue()!=null){
                            collectUsersProducts((Map<String,Object>) dataSnapshot.getValue());

                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        //handle databaseError
                        Log.d("pp-f","fuckckckckc");
                    }
                });

        searchByText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                (MainActivity.this).shproductAdapter.getFilter().filter(s);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        search_BTN_camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,cameraActivity.class);
                intent.putExtra("myLocation",myLocation);
                startActivity(intent);
                finish();

            }
        });

        asosSearch_btn.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this,SearchActivity.class);
            intent.putExtra("categoryId","");
            intent.putExtra("imageColorNumber","");
            startActivity(intent);
            finish();
        });

        user_page_btn.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this,UserPageActivity.class);
            startActivity(intent);
            finish();
        });

        addProductPage_btn.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this,AddProductActivity.class);
            startActivity(intent);
            finish();
        });
        shoppingCart_btn.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this,ShoppingCartActivity.class);
            startActivity(intent);
            finish();
        });
        wishList_btn.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this,WishListActivity.class);
            startActivity(intent);
            finish();
        });


    }
    private void collectUsersProducts(Map<String,Object> users) {

        ArrayList<SHProduct> productInfo = new ArrayList<>();

        //iterate through each user, ignoring their UID
        for (Map.Entry<String, Object> entry : users.entrySet()){

            //Get user map
            Map singleUser = (Map) entry.getValue();

            String image = String.valueOf(singleUser.get("url"));
            String category = String.valueOf(singleUser.get("category"));
            String color = String.valueOf(singleUser.get("color"));
            String condition = String.valueOf(singleUser.get("condition"));
            String description = String.valueOf(singleUser.get("description"));
            String price = String.valueOf(singleUser.get("price"));
            String name = String.valueOf(singleUser.get("productName"));
            String shippingOption = String.valueOf(singleUser.get("shippingOption"));

            productInfo.add(new SHProduct(image, name, price, condition, description, shippingOption, color, category));
            setSHProductRecycler(productInfo);
        }
    }

    private void  setSHProductRecycler(List<SHProduct> shProducts){
              shproductRecycler = findViewById(R.id.product_racycale);
              RecyclerView.LayoutManager LayoutManager = new LinearLayoutManager(this , RecyclerView.VERTICAL,false);
              shproductRecycler.setLayoutManager(LayoutManager);
              shproductAdapter=new SHProductAdapter(this,shProducts,shProducts);
              shproductRecycler.setAdapter(shproductAdapter);
    }
}