package com.example.dressupapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageButton;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class UserPageActivity extends AppCompatActivity {

    ImageButton back_btn;
    ImageButton setting_btn;
    Button myCloset_btn;
    Button myOrder_btn;
    Button remove_btn;

    MyOrderAdapter myOrderAdapter;
    RecyclerView myOrderRecycler;

    MyClosetAdapter myClosetAdapter;
    RecyclerView myClosetRecycler;
    private DatabaseReference rootDatabaseref;
    private DatabaseReference rootSecondDatabaseref;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_page);

        back_btn = findViewById(R.id.userPage_BTN_back);
        setting_btn = findViewById(R.id.userPage_BTN_setting);
        myCloset_btn = findViewById(R.id.btnMyCloset) ;
        myOrder_btn = findViewById(R.id.btnMyOrder);
        setListOfMyOrder();


        back_btn.setOnClickListener(view -> {
            Intent intent = new Intent(UserPageActivity.this,MainActivity.class);
            startActivity(intent);
            finish();
        });

        setting_btn.setOnClickListener(view -> {
            Intent intent = new Intent(UserPageActivity.this,SettingActivity.class);
            startActivity(intent);
            finish();

        });
        myCloset_btn.setOnClickListener(view -> {
            setListOfMyCloset();
        });

        myOrder_btn.setOnClickListener(view -> {
            setListOfMyOrder();
        });
    }

    private void setListOfMyOrder() {
        List<MyOrder> myOrderList = new ArrayList<>();
        myOrderList.add(new MyOrder("150","1","XL"));
        myOrderList.add(new MyOrder("650","1","XL"));
        myOrderList.add(new MyOrder("450","1","L"));
        myOrderList.add(new MyOrder("1500","2","XS"));
        myOrderList.add(new MyOrder("150","1","OS"));
        myOrderList.add(new MyOrder("100","1","S"));
        myOrderList.add(new MyOrder("110","1","XL"));
        myOrderList.add(new MyOrder("80","1","M"));
        setMyOrderRecycler(myOrderList);
    }

    private void setListOfMyCloset() {

        rootDatabaseref = FirebaseDatabase.getInstance().getReference().child("User");
        rootSecondDatabaseref = rootDatabaseref.child("Products");
        rootSecondDatabaseref.addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        //Get map of users in datasnapshot
                        collectUsersProducts((Map<String,Object>) dataSnapshot.getValue());
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        //handle databaseError
                        Log.d("pp-userpage","databaseError"+databaseError);
                    }
                });


    }

    private void collectUsersProducts(Map<String, Object> users) {


        ArrayList<MyCloset> productInfo = new ArrayList<>();
            //iterate through each user, ignoring their UID
            for (Map.Entry<String, Object> entry : users.entrySet()){

                //Get user map
                Map singleUser = (Map) entry.getValue();


                String category = String.valueOf(singleUser.get("category"));
                String color = String.valueOf(singleUser.get("color"));
                String condition = String.valueOf(singleUser.get("condition"));
                String description = String.valueOf(singleUser.get("description"));
                String price = String.valueOf(singleUser.get("price"));
                String name = String.valueOf(singleUser.get("productName"));
                String shippingOption = String.valueOf(singleUser.get("shippingOption"));


                productInfo.add(new MyCloset(name,category, color,shippingOption,condition, shippingOption,price,description));
                setMyClosetRecycler(productInfo);
            }
        }




    private void setMyClosetRecycler(List<MyCloset> myClosetList) {
        myClosetRecycler = findViewById(R.id.recyclerView_myOrder_myCloset);
        RecyclerView.LayoutManager LayoutManager = new LinearLayoutManager(this , RecyclerView.VERTICAL,false);
        myClosetRecycler.setLayoutManager(LayoutManager);
        myClosetAdapter=new MyClosetAdapter(this,myClosetList);
        myClosetRecycler.setAdapter(myClosetAdapter);
    }

    private void setMyOrderRecycler(List<MyOrder> myOrderList) {
        myOrderRecycler = findViewById(R.id.recyclerView_myOrder_myCloset);
        RecyclerView.LayoutManager LayoutManager = new LinearLayoutManager(this , RecyclerView.VERTICAL,false);
        myOrderRecycler.setLayoutManager(LayoutManager);
        myOrderAdapter=new MyOrderAdapter(this,myOrderList);
        myOrderRecycler.setAdapter(myOrderAdapter);
    }
}