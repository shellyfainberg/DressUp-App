package com.example.dressupapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;


public class ShoppingCartAdapter extends RecyclerView.Adapter<ShoppingCartAdapter.ShoppingCartViewHolder> {
    Context context;
    List<ShoppingCart> shoppingCartList;

    public ShoppingCartAdapter(Context context, List<ShoppingCart> shoppingCartList) {
        this.context = context;
        this.shoppingCartList = shoppingCartList;
    }

    @NonNull
    @Override
    public ShoppingCartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(context).inflate(R.layout.activity_shoppingcart_list,parent,false);
        return new ShoppingCartViewHolder(view);
    }

    public static final class ShoppingCartViewHolder extends RecyclerView.ViewHolder{
        TextView ProductName;
        TextView ProductPrice;


        public ShoppingCartViewHolder(@NonNull View itemView) {
            super(itemView);
            ProductName= itemView.findViewById(R.id.shoppingCartList_TXT_name);
            ProductPrice= itemView.findViewById(R.id.shoppingCartList_TXT_price);


        }
    }

    @Override
    public void onBindViewHolder(@NonNull ShoppingCartAdapter.ShoppingCartViewHolder holder, int position) {
        holder.ProductName. setText(shoppingCartList.get(position).getProductName());
        holder.ProductPrice.setText(shoppingCartList.get(position).getPrice());

    }

    @Override
    public int getItemCount() {

        return shoppingCartList.size();
    }
}
