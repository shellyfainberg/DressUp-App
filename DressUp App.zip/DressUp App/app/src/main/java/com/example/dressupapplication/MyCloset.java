package com.example.dressupapplication;

import android.widget.ImageButton;
import android.widget.ImageView;

public class MyCloset {

    ImageButton imageN1;
    ImageButton imageN2;
    ImageButton imageN3;
    String title;
    String category;
    String color;
    String shippingOption;
    String condition;
    String setLocation;
    String price;
    String description;
//    String count;
//    String size;

    public MyCloset(String title, String category, String color, String shippingOption, String condition, String setLocation, String price, String description) {
        this.title = title;
        this.category = category;
        this.color = color;
        this.shippingOption = shippingOption;
        this.condition = condition;
        this.setLocation = setLocation;
        this.price = price;
        this.description = description;
//        this.count = count;
//        this.size = size;
    }

//    public String getSize() {
//        return size;
//    }
//
//    public void setSize(String size) {
//        this.size = size;
//    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getShippingOption() {
        return shippingOption;
    }

    public void setShippingOption(String shippingOption) {
        this.shippingOption = shippingOption;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getSetLocation() {
        return setLocation;
    }

    public void setSetLocation(String setLocation) {
        this.setLocation = setLocation;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

//    public String getCount() {
//        return count;
//    }
//
//    public void setCount(String count) {
//        this.count = count;
//    }
}
