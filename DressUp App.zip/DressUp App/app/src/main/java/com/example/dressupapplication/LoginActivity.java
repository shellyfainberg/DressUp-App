package com.example.dressupapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.hbb20.CountryCodePicker;

public class LoginActivity extends AppCompatActivity {


    CountryCodePicker login_BTN_cpp;
    EditText login_EDT_phoneNumber;
    Button login_BTN_login;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        login_BTN_cpp = (CountryCodePicker)findViewById(R.id.login_BTN_cpp);
        login_EDT_phoneNumber = findViewById(R.id.login_EDT_phoneNumber);
        login_BTN_login = findViewById(R.id.login_BTN_login);
        login_BTN_cpp.registerCarrierNumberEditText(login_EDT_phoneNumber);


        login_BTN_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, manageotp.class);
                intent.putExtra("mobile",login_BTN_cpp.getFullNumberWithPlus().replace(" ",""));
                startActivity(intent);

            }
        });


    }
}